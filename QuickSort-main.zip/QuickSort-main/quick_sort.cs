﻿using System;

class Sort
{
	public static int partition(int[] arr, int low, int high)
	{
		int pivot = arr[low];
		int i = low; int j = high;
		while (i<j)
		{
			while (arr[i] < pivot)
				i++;
			while (arr[j] > pivot)
				j--;
			if (i<j)
			{
				int temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
			}
		}
		return j;
	}

	static public void quickSort(int[] arr, int low, int high)
	{
		// For Recusrion  
		if (low < high)
		{
			int pivot = partition(arr, low, high);
			if (pivot > 1)
				quickSort(arr, low, pivot - 1);
			if (pivot + 1 < high)
				quickSort(arr, pivot + 1, high);
		}
	}
}

public class App
{
	public static void Main(string[] args)
	{
		var arr = new int[9] { 10, 16, 8, 12, 15, 6, 3, 9, 5 };
		Sort.quickSort(arr, 0, arr.Length-1);
		for (int i = 0; i < arr.Length; i++)
			Console.Write(arr[i]+" ");
	}
}
