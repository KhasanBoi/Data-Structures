using System;

public class Node
{
	public int data;
	public Node next;
	
	public Node(int data)
	{
		this.data = data;
		next = null;
	}
}

class LinkedList
{
	Node head;
	
	public LinkedList()
	{
		head = null;
	}
	
	public void AddNodeToFront(int data)
	{
		var temp = new Node(data);
		temp.next = head;
		head = temp;
	}
	public void AddNodeToEnd(int data)
	{
		var node = new Node(data);
		if(head == null)
		{
			head = node;
		}
		else
		{
			Node temp = head;
			while(temp.next != null)
			{
				temp = temp.next;
			}
			temp.next = node;
		}
	}
	public void AddNodeToMiddle(int data, int pos)
	{
		var node = new Node(data);
		if(head == null)
		{
			head = node;
		}
		else
		{
			Node cur = head;
			Node pre = head;
			for(int i=0; i<pos; i++)
			{
				pre = cur;
				cur = cur.next;				
			}
			pre.next = node;
			node.next = cur.next;
			cur = null;
		}
	}
	public void DeleteNodeWithData(int data)
	{
		if(head == null)
		{
			Console.WriteLine("The List is empty");
		}
		else
		{
			Node cur = head;
			Node pre = head;
			while(cur.data != data)
			{
				pre = cur;
				cur = cur.next;
			}
			pre.next = cur.next;
			cur = null;
		}
	}
	public void DeleteNodeWithIndex(int pos)
	{
		if(head == null)
		{
			Console.WriteLine("The List in empty");
		}
		else
		{
			Node cur = head;
			Node pre = head;
			for(int i=0; i<pos; i++)
			{
				pre = cur;
				cur = cur.next;
			}
			pre.next = cur.next;
			cur = null;
		}
	}
	public void PrintList()
	{
		Node temp = head;
		if(temp == null)
		{
			Console.WriteLine(temp.data);
		}
		while(temp != null)
		{
			Console.WriteLine(temp.data);
			temp = temp.next;
		}
	}
}

public class Program
{
	public static void Main()
	{
		var listOne = new LinkedList();
		listOne.AddNodeToEnd(4);
		listOne.AddNodeToEnd(12);
		listOne.AddNodeToEnd(9);
		listOne.AddNodeToEnd(5);
		listOne.AddNodeToEnd(16);
		listOne.PrintList();
		Console.WriteLine("=====");
		listOne.AddNodeToFront(290);
		Console.WriteLine("Added a node at the front");
		listOne.PrintList();
		Console.WriteLine("=====");
		Console.WriteLine("Added a node after 2nd element");
		listOne.AddNodeToMiddle(133,2);
		listOne.PrintList();
		Console.WriteLine("=====");
		Console.WriteLine("Delete 9 from the list");
		listOne.DeleteNodeWithData(9);
		listOne.PrintList();
		Console.WriteLine("=====");
	}
}